# ID 116346090
def minimum_platforms(robots: list[int], limits: int) -> int:
    left_pointer = 0
    right_pointer = len(robots) - 1
    count = 0

    while left_pointer <= right_pointer:
        max_count = robots[left_pointer] + robots[right_pointer]
        if max_count <= limits:
            left_pointer += 1
        count += 1
        right_pointer -=1
    return int(count)

if __name__ == "__main__":
    robots = sorted([int(x) for x in input().split()])
    limits = int(input())
    result = minimum_platforms(robots, limits)
    print(result)
