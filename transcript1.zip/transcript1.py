# 117130444
def transcript(line: str) -> str:
    stak = []
    given_str = given_num = ''
    for char in line:
        if char.isdigit():
            given_num += char
        elif char == '[':
            stak.append((int(given_num), given_str))
            given_str = given_num = ''
        elif char == ']':
            num, prev_str = stak.pop()
            given_str = prev_str + num * given_str
        else:
            given_str += char
    return given_str

if __name__ == '__main__':
    compressed_string = str(input())
    result = transcript(compressed_string)
    print(result)